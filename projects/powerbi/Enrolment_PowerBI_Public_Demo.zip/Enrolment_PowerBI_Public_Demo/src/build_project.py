"""Build the Power BI project from the prepared CSV files. Python standard library only."""
import pathlib,json,csv,uuid,sys,gzip,base64,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def write(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
def literal(value):return {'expr':{'Literal':{'Value':"'"+value.replace("'","''")+"'"}}}
def color(hex):return {'solid':{'color':literal(hex)}}
def field(table,column,measure=False):return {('Measure' if measure else 'Column'):{'Expression':{'SourceRef':{'Entity':table}},'Property':column}}
def build(root):
 modeldir=root/'Enrolment.SemanticModel';reportdir=root/'Enrolment.Report';definitions=reportdir/'definition'
 write(root/'Enrolment_Status.pbip',{'version':'1.0','artifacts':[{'report':{'path':'Enrolment.Report'}}],'settings':{'enableAutoRecovery':True}})
 write(modeldir/'definition.pbism',{'version':'1.0','settings':{}})
 write(reportdir/'definition.pbir',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json','version':'4.0','datasetReference':{'byPath':{'path':'../Enrolment.SemanticModel'}}})
 def table(name,intcols=[],doublecols=[],datecols=[]):
  rows=list(csv.DictReader((root/'data'/f'{name}.csv').open(encoding='utf-8-sig')));columns=[];types=[]
  for c in rows[0]:
   typ='int64' if c in intcols else 'double' if c in doublecols else 'dateTime' if c in datecols else 'string';mtyp='Int64.Type' if typ=='int64' else 'type number' if typ=='double' else 'type date' if typ=='dateTime' else 'type text'
   col={'name':c,'dataType':typ,'sourceColumn':c,'summarizeBy':'none'}
   if typ in ['int64','double']:col['formatString']='#,0' if typ=='int64' else '0.0'
   if typ=='dateTime':col['formatString']='dd MMM yyyy'
   columns.append(col);types.append('{'+json.dumps(c)+', '+mtyp+'}')
  expr=['let',f'    Source = Csv.Document(File.Contents(DataFolder & "{name}.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),','    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),','    Blanks = Table.ReplaceValue(Headers, "", null, Replacer.ReplaceValue, Table.ColumnNames(Headers)),','    Typed = Table.TransformColumnTypes(Blanks, {'+', '.join(types)+'}, "en-US")','in','    Typed']
  return {'name':name,'columns':columns,'partitions':[{'name':name,'mode':'import','source':{'type':'m','expression':expr}}]}
 ints=['InMain','InFuzzy','InQueue','MainQualityYes','MainQualityMissing','MainIncompleteSR','CVCompleted','MainOperationalSchool','MainNotContact','MainAgeDifference3Plus','MainCurrentEligibility','MainCurrentQualityYes','MainEligibilityFlagMismatch','LowOriginalFuzzy','LowNewFuzzy','LowOriginalQueued','LowOriginalNotQueued','FuzzyOutsideMain','QueueOutsideMain','Priority']
 fact=table('FactCases',ints,['OriginalScore','NewScore','Age'],['DateOfEnrolment']);loc=table('DimLocation');rules=table('QualityRules');rules['isHidden']=True
 measures={
 'Main Enrolments':('SUM(FactCases[InMain])','#,0'),
 'Fuzzy Export Cases':('SUM(FactCases[InFuzzy])','#,0'),
 'Verification Queue':('SUM(FactCases[InQueue])','#,0'),
 'Quality Flag Yes':('SUM(FactCases[MainQualityYes])','#,0'),
 'Quality Flag Missing':('SUM(FactCases[MainQualityMissing])','#,0'),
 'Quality Flag Rate':('DIVIDE([Quality Flag Yes], [Main Enrolments])','0.0%'),
 'Incomplete SR':('SUM(FactCases[MainIncompleteSR])','#,0'),
 'Incomplete SR Rate':('DIVIDE([Incomplete SR], [Main Enrolments])','0.0%'),
 'Low Original Fuzzy':('SUM(FactCases[LowOriginalFuzzy])','#,0'),
 'Low New Fuzzy':('SUM(FactCases[LowNewFuzzy])','#,0'),
 'Low Original Rate':('DIVIDE([Low Original Fuzzy], [Fuzzy Export Cases])','0.0%'),
 'Low New Rate':('DIVIDE([Low New Fuzzy], [Fuzzy Export Cases])','0.0%'),
 'Low Original Queued':('SUM(FactCases[LowOriginalQueued])','#,0'),
 'Low Original Not Queued':('SUM(FactCases[LowOriginalNotQueued])','#,0'),
 'Queue Coverage Rate':('DIVIDE([Low Original Queued], [Low Original Fuzzy])','0.0%'),
 'BO Pending':('CALCULATE(COUNTROWS(FactCases), FactCases[InQueue] = 1, FactCases[BOStatus] = "Pending for Approval/Rejection")','#,0'),
 'BO Unmatch':('CALCULATE(COUNTROWS(FactCases), FactCases[InQueue] = 1, FactCases[BOStatus] = "Unmatch")','#,0'),
 'BO Approved':('CALCULATE(COUNTROWS(FactCases), FactCases[InQueue] = 1, FactCases[BOStatus] IN {"Approved", "Approve"})','#,0'),
 'Completed CV Main':('CALCULATE(COUNTROWS(FactCases), FactCases[InMain] = 1, FactCases[CVCompleted] = 1)','#,0'),
 'Completed CV Fuzzy':('CALCULATE(COUNTROWS(FactCases), FactCases[InFuzzy] = 1, FactCases[CVCompleted] = 1)','#,0'),
 'Completed CV Queue':('CALCULATE(COUNTROWS(FactCases), FactCases[InQueue] = 1, FactCases[CVCompleted] = 1)','#,0'),
 'Fuzzy Outside Main':('SUM(FactCases[FuzzyOutsideMain])','#,0'),
 'Queue Outside Main':('SUM(FactCases[QueueOutsideMain])','#,0'),
 'Main And Fuzzy':('CALCULATE(COUNTROWS(FactCases), FactCases[InMain] = 1, FactCases[InFuzzy] = 1)','#,0'),
 'Main Only Vs Fuzzy':('CALCULATE(COUNTROWS(FactCases), FactCases[InMain] = 1, FactCases[InFuzzy] = 0)','#,0'),
 'Distinct Case Universe':('COUNTROWS(FactCases)','#,0'),
 'Current Main Enrolments':('CALCULATE([Main Enrolments], KEEPFILTERS(FactCases[EnrolmentYear] = "2026-2027"))','#,0'),
 'Current QE Flag Yes':('SUM(FactCases[MainCurrentQualityYes])','#,0'),
 'Current Eligibility Proxy':('SUM(FactCases[MainCurrentEligibility])','#,0'),
 'Eligibility Flag Mismatch':('SUM(FactCases[MainEligibilityFlagMismatch])','#,0'),
 'Main Score Missing':('CALCULATE(COUNTROWS(FactCases), FactCases[InMain] = 1, ISBLANK(FactCases[OriginalScore]))','#,0'),
 'Original Average Fuzzy':('CALCULATE(AVERAGE(FactCases[OriginalScore]), FactCases[InFuzzy] = 1)','0.0'),
 'New Average Fuzzy':('CALCULATE(AVERAGE(FactCases[NewScore]), FactCases[InFuzzy] = 1)','0.0'),
 'Main Operational School':('SUM(FactCases[MainOperationalSchool])','#,0'),
 'Main No Contact':('SUM(FactCases[MainNotContact])','#,0'),
 'Age Difference 3 Plus':('SUM(FactCases[MainAgeDifference3Plus])','#,0'),
 'Action Cases':('CALCULATE(COUNTROWS(FactCases), FactCases[Priority] < 3)','#,0'),
 'Case Count':('COUNTROWS(FactCases)','#,0'),
 'Incomplete SR RAG':('VAR Rate = [Incomplete SR Rate] RETURN IF(ISBLANK(Rate), "N/A", SWITCH(TRUE(), Rate > 0.20, "Red", Rate >= 0.10, "Amber", "Green"))',None)
 }
 # COUNTROWS over an empty set returns BLANK in DAX: show confirmed zero counts, but leave division results unavailable on zero denominators.
 for name,(expr,fmt) in list(measures.items()):
  if fmt=='#,0':measures[name]=('COALESCE('+expr+', 0)',fmt)
 fact['measures']=[dict(name=n,expression=e,displayFolder='Status Metrics',**({'formatString':f} if f else {})) for n,(e,f) in measures.items()]
 loc['hierarchies']=[{'name':'Geography','levels':[{'name':c,'ordinal':i,'column':c} for i,c in enumerate(['District','Block','Cluster','Village','School'])]}]
 model={'name':'EnrolmentStatus','compatibilityLevel':1600,'model':{'culture':'en-US','sourceQueryCulture':'en-US','defaultPowerBIDataSourceVersion':'powerBI_V3','tables':[fact,loc,rules],'relationships':[{'name':str(uuid.uuid4()),'fromTable':'FactCases','fromColumn':'LocationKey','toTable':'DimLocation','toColumn':'LocationKey','crossFilteringBehavior':'oneDirection','fromCardinality':'many','toCardinality':'one'}],'expressions':[{'name':'DataFolder','kind':'m','expression':'"C:/Enrolment_Status_PowerBI/data/" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'}],'annotations':[{'name':'PBI_QueryOrder','value':json.dumps(['DataFolder','DimLocation','FactCases','QualityRules'])}]}}
 write(modeldir/'model.bim',model)
 (root/'DAX_Measures.dax').write_text('\n\n'.join(n+' =\n'+e for n,(e,_) in measures.items()))
 write(root/'Enrolment_Theme.json',{'name':'Enrolment Status','dataColors':['#7657F6','#18A999','#F6AC45','#E65A81','#3498DB','#344264'],'background':'#F2EFFB','foreground':'#202944','tableAccent':'#7657F6'})
 write(definitions/'version.json',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json','version':'2.0.0'})
 write(definitions/'report.json',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.0.0/schema.json','themeCollection':{}})
 pages=[];visualcount=0
 def projection(table,column,measure=False):return {'field':field(table,column,measure),'queryRef':table+'.'+column,'nativeQueryRef':column}
 def page(number,title):
  name=f'page{number:02}';path=definitions/'pages'/name;pages.append(name)
  write(path/'page.json',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.0.0/schema.json','name':name,'displayName':title,'displayOption':'FitToWidth','width':1280,'height':3020,'objects':{'background':[{'properties':{'color':color('#F2EFFB'),'transparency':{'expr':{'Literal':{'Value':'0D'}}}}}]}})
  return path
 def visual(path,kind,title,x,y,w,h,query=None,dark=False):
  nonlocal visualcount
  visualcount+=1;name=f'v{visualcount:04}'
  config={'visualType':kind,'drillFilterOtherVisuals':True,'visualContainerObjects':{'title':[{'properties':{'show':{'expr':{'Literal':{'Value':'true'}}},'text':literal(title),'fontColor':color('#FFFFFF' if dark else '#202944'),'fontSize':{'expr':{'Literal':{'Value':'12D'}}},'titleWrap':{'expr':{'Literal':{'Value':'true'}}}}}],'background':[{'properties':{'show':{'expr':{'Literal':{'Value':'true'}}},'color':color('#202944' if dark else '#FFFFFF'),'transparency':{'expr':{'Literal':{'Value':'0D'}}}}}]}}
  if query:config['query']={'queryState':query}
  if dark:config['objects']={'labels':[{'properties':{'color':color('#FFFFFF'),'fontSize':{'expr':{'Literal':{'Value':'28D'}}}}}],'categoryLabels':[{'properties':{'show':{'expr':{'Literal':{'Value':'false'}}}}}]}
  write(path/'visuals'/name/'visual.json',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.4.0/schema.json','name':name,'position':{'x':x,'y':y,'z':visualcount,'width':w,'height':h,'tabOrder':visualcount},'visual':config})
 def card(path,title,index):visual(path,'card',title,24+index*208,100,196,120,{'Values':{'projections':[projection('FactCases',title,True)]}},True)
 def slicers(path):
  for i,(table,col,title) in enumerate([('DimLocation','District','District'),('DimLocation','Block','Block'),('FactCases','EnrolmentYear','Enrolment year')]):visual(path,'slicer',title,24+i*416,16,400,68,{'Values':{'projections':[projection(table,col)]}})
 def chart(path,kind,title,category,metrics,x,y,w,h,entity='DimLocation'):
  visual(path,kind,title,x,y,w,h,{'Category':{'projections':[projection(entity,category)]},'Y':{'projections':[projection('FactCases',m,True) for m in metrics]}})
 def tablevis(path,title,columns,x,y,w,h):visual(path,'tableEx',title,x,y,w,h,{'Values':{'projections':[projection(*c) for c in columns]}})
 # Rebuild one page only; remove obsolete generated pages from earlier layouts.
 if (definitions/'pages').exists():
  import shutil
  shutil.rmtree(definitions/'pages')
 p=page(1,'Enrolment | Complete Dashboard');slicers(p)
 metrics=['Main Enrolments','Quality Flag Yes','Incomplete SR','Fuzzy Export Cases','Verification Queue','Completed CV Main','Low Original Fuzzy','Low Original Queued','Low Original Not Queued','Low New Fuzzy','BO Pending','Quality Flag Missing']
 for i,m in enumerate(metrics):
  visual(p,'card',m,24+(i%6)*208,100+(i//6)*110,196,94,{'Values':{'projections':[projection('FactCases',m,True)]}},True)
 chart(p,'clusteredBarChart','Enrolment and quality by district','District',['Main Enrolments','Quality Flag Yes','Incomplete SR'],24,328,600,250)
 chart(p,'lineChart','Enrolments by admission month','Month',['Main Enrolments'],644,328,612,250,'FactCases')
 chart(p,'clusteredBarChart','Original vs new scores below 70: separate indicators','District',['Low Original Fuzzy','Low New Fuzzy'],24,598,600,250)
 chart(p,'clusteredColumnChart','Original score bands in fuzzy export','OriginalBand',['Fuzzy Export Cases'],644,598,612,250,'FactCases')
 chart(p,'clusteredBarChart','Quality flag: missing does not mean failed','MainQualityStatus',['Main Enrolments'],24,868,600,240,'FactCases')
 chart(p,'clusteredBarChart','School register status','MainStatus',['Main Enrolments'],644,868,612,240,'FactCases')
 chart(p,'clusteredBarChart','Suggested follow-up actions','Action',['Case Count'],24,1128,600,250,'FactCases')
 chart(p,'clusteredBarChart','Priority cases by block','Block',['Action Cases'],644,1128,612,250)
 tablevis(p,'District enrolment, quality and eligibility: proxy is not official quality',[('DimLocation','District',False)]+[('FactCases',m,True) for m in ['Main Enrolments','Quality Flag Rate','Incomplete SR Rate','Current Main Enrolments','Current QE Flag Yes','Current Eligibility Proxy','Eligibility Flag Mismatch','Main Score Missing']],24,1398,1232,210)
 tablevis(p,'Verification workflow: queue presence is not completed verification',[('DimLocation','District',False)]+[('FactCases',m,True) for m in ['Low Original Queued','Queue Coverage Rate','BO Pending','BO Unmatch','BO Approved','Completed CV Main','Completed CV Fuzzy','Completed CV Queue','Original Average Fuzzy','New Average Fuzzy']],24,1628,1232,190)
 tablevis(p,'Quality and follow-up by block',[('DimLocation','District',False),('DimLocation','Block',False)]+[('FactCases',m,True) for m in ['Main Enrolments','Quality Flag Yes','Quality Flag Missing','Incomplete SR','Incomplete SR Rate','Incomplete SR RAG','Main Operational School','Age Difference 3 Plus','Main No Contact','Action Cases']],24,1838,1232,230)
 tablevis(p,'Private case detail: use private CaseLookup.csv for source IDs',[('FactCases','CaseID',False),('DimLocation','District',False),('DimLocation','Block',False),('DimLocation','Cluster',False),('DimLocation','Village',False),('DimLocation','School',False),('FactCases','Action',False),('FactCases','MainStatus',False),('FactCases','BOStatus',False),('FactCases','IOStatus',False),('FactCases','CVStatus',False),('FactCases','OriginalScore',False),('FactCases','NewScore',False)],24,2088,1232,340)
 tablevis(p,'Source reconciliation: overlapping exports must not be added',[('DimLocation','District',False),('FactCases','EnrolmentYear',False)]+[('FactCases',m,True) for m in ['Distinct Case Universe','Main Enrolments','Fuzzy Export Cases','Verification Queue','Main And Fuzzy','Main Only Vs Fuzzy','Fuzzy Outside Main','Queue Outside Main']],24,2448,1232,220)
 tablevis(p,'Supplied quality rules: official summary inputs were empty',[('QualityRules','Indicator',False),('QualityRules','Definition',False),('QualityRules','AlertCriteria',False),('QualityRules','Critical',False)],24,2688,1232,300)
 write(definitions/'pages/pages.json',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json','pageOrder':pages,'activePageName':pages[0]})
 print(json.dumps({'pages':len(pages),'visuals':visualcount,'measures':len(measures),'tables':3}))
def embed_snapshot(root):
 model_path=root/'Enrolment.SemanticModel/model.bim'
 model=json.loads(model_path.read_text(encoding='utf-8'))
 receipts=[]
 for table in model['model']['tables']:
  name=table['name'];raw=(root/'data'/f'{name}.csv').read_bytes()
  payload=base64.b64encode(gzip.compress(raw,mtime=0)).decode('ascii')
  chunks=[payload[i:i+8000] for i in range(0,len(payload),8000)]
  expression=table['partitions'][0]['source']['expression']
  expression[1:2]=[
   '    Snapshot = Text.Combine({'+', '.join(json.dumps(x) for x in chunks)+'}),',
   '    Bytes = Binary.Decompress(Binary.FromText(Snapshot, BinaryEncoding.Base64), Compression.GZip),',
   '    Source = Csv.Document(Bytes, [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),'
  ]
  (root/'PowerQuery').mkdir(exist_ok=True)
  (root/'PowerQuery'/f'{name}.pq').write_text('\n'.join(expression),encoding='utf-8')
  receipts.append({'table':name,'csv_sha256':hashlib.sha256(raw).hexdigest(),'csv_bytes':len(raw),'rows':len(list(csv.DictReader(raw.decode('utf-8-sig').splitlines())))})
 model['model'].pop('expressions',None)
 for a in model['model'].get('annotations',[]):
  if a['name']=='PBI_QueryOrder':a['value']=json.dumps(['DimLocation','FactCases','QualityRules'])
 write(model_path,model)
 write(root/'Snapshot_Manifest.json',{'snapshot_date':'2026-10-11','mode':'embedded static snapshot','external_paths_required':False,'tables':receipts,'refresh_note':'Refresh reloads the embedded snapshot. New exports require rebuilding this project with src/prepare_data.py and src/build_project.py.'})
 print('Embedded snapshot: no external data-folder dependency')
if __name__=='__main__':
 target=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else ROOT
 build(target)
 embed_snapshot(target)

