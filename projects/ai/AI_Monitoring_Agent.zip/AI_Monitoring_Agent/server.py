"""Local-only UI. Start: python server.py ; open http://127.0.0.1:8765"""
import http.server,json,pathlib,urllib.parse,os
import agent
ROOT=pathlib.Path(__file__).resolve().parent
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def reply(self,status,value):
  body=json.dumps(value,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
 def do_GET(self):
  name=urllib.parse.urlsplit(self.path).path
  if name=='/config':return self.reply(200,{'ai_ready':bool(os.environ.get('GEMINI_API_KEY') and os.environ.get('GEMINI_MODEL'))})
  files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/sample.csv':'sample/monitoring.csv'}
  if name not in files:return self.reply(404,{'error':'Not found'})
  body=(ROOT/files[name]).read_bytes();self.send_response(200);self.send_header('Content-Type',{'/':'text/html; charset=utf-8','/app.js':'text/javascript','/style.css':'text/css','/sample.csv':'text/csv'}[name]);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
 def do_POST(self):
  if self.path!='/analyze':return self.reply(404,{'error':'Not found'})
  # Bind localhost, require same-origin fetch custom header, refuse cross-site requests.
  if self.headers.get('X-Monitoring-Agent')!='local-ui':return self.reply(403,{'error':'Use the local app'})
  origin=self.headers.get('Origin')
  if origin and origin!='http://127.0.0.1:8765':return self.reply(403,{'error':'Origin rejected'})
  try:
   n=int(self.headers.get('Content-Length','0'))
   if not 0<n<=8*1024*1024:raise agent.DataError('Input must be smaller than 8 MiB')
   value=json.loads(self.rfile.read(n));text=value['csv'];language=value.get('language','en')
   if not isinstance(text,str) or language not in ('hi','en'):raise agent.DataError('Invalid request')
   result=agent.run(text,language,value.get('ai') is True,classification='synthetic' if value.get('sample') is True else 'user-provided');folder=agent.save(result,text,ROOT/'reports');return self.reply(200,{'result':result,'markdown':agent.markdown(result),'prompt':agent.prompt_text(result),'saved_folder':folder.name})
  except (agent.DataError,ValueError,KeyError,TypeError):return self.reply(400,{'error':'CSV validation failed. Check required columns, unique IDs, source flags and score range.'})
  except OSError:return self.reply(500,{'error':'Could not save report output'})
if __name__=='__main__':
 print('Open http://127.0.0.1:8765 — stop with Ctrl+C')
 try:http.server.ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
 except KeyboardInterrupt:pass
