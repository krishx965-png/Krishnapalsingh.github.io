import unittest,pathlib,tempfile,csv,io,json,os,urllib.error
from unittest.mock import patch
import agent
class AgentTests(unittest.TestCase):
 def setUp(self):self.text=(pathlib.Path(__file__).parent/'sample/monitoring.csv').read_text(encoding='utf-8-sig');self.rows=agent.load_csv(self.text)
 def altered(self,key,value):
  rs=list(csv.DictReader(io.StringIO(self.text)));rs[0][key]=value;buf=io.StringIO();w=csv.DictWriter(buf,fieldnames=rs[0].keys());w.writeheader();w.writerows(rs);return buf.getvalue()
 def test_totals_populations(self):
  m=agent.metrics(self.rows)
  for k,v in {'union_cases':111,'main':100,'fuzzy':90,'queue':11,'quality_yes':70,'incomplete_sr':15,'low_original':20,'low_queued':10,'low_not_queued':10,'bo_pending':9,'bo_approved':1,'bo_unmatch':1,'cv_main':2,'cv_queue':1,'queue_coverage_pct':50.0}.items():self.assertEqual(m[k],v,k)
 def test_district_reconciliation(self):
  r=agent.analyze(self.rows);self.assertEqual(sum(d['metrics']['main'] for d in r['districts']),100);self.assertEqual(r['districts'][0]['metrics']['main'],52)
 def test_duplicates_stop(self):
  with self.assertRaises(agent.DataError):agent.load_csv(self.text+self.text.splitlines()[1]+'\n')
 def test_invalid_score_and_flags(self):
  for k,v in [('OriginalScore','101'),('OriginalScore','NaN'),('InMain','2'),('CaseID',''),('MainQualityStatus','confirmed')]:
   with self.subTest(k=k,v=v),self.assertRaises(agent.DataError):agent.load_csv(self.altered(k,v))
 def test_missing_and_empty(self):
  for t in ['CaseID\nx\n',self.text.splitlines()[0]+'\n']:
   with self.assertRaises(agent.DataError):agent.load_csv(t)
 def test_null_score_not_zero(self):
  row=agent.load_csv(self.altered('OriginalScore',''))[0];self.assertIsNone(row['OriginalScore']);self.assertEqual(agent.metrics([row])['low_original'],0)
 def test_no_denominator_and_rag_boundary(self):
  r=dict(self.rows[0]);r['InMain']=0;self.assertIsNone(agent.metrics([r])['quality_pct']);self.assertEqual(agent.metrics([r])['sr_rag'],'N/A')
  rs=[dict(self.rows[0]) for _ in range(10)]
  for n,expected in [(0,'Green'),(1,'Amber'),(2,'Amber'),(3,'Red')]:
   for i,r in enumerate(rs):r['MainStatus']='Incomplete SR' if i<n else 'Complete SR'
   self.assertEqual(agent.metrics(rs)['sr_rag'],expected)
 def test_ai_excludes_identities(self):
  payload=json.dumps(agent.ai_payload(agent.analyze(self.rows)));self.assertNotIn('DEMO-0001',payload);self.assertNotIn('District A',payload);self.assertNotIn('Demo Block',payload)
 def test_ai_numeric_and_metric_rejected(self):
  for val in [{'headline':'Status 99','observations':[]},{'headline':'Status','observations':[{'metric_key':'invented','note':'Check','action':'Follow up'}]}]:
   with self.assertRaises(agent.DataError):agent.validate_ai(val,{'bo_pending'})
 def test_missing_key_fallback(self):
  with patch.dict(os.environ,{},clear=True):r=agent.run(self.text,use_ai=True)
  self.assertEqual(r['mode'],'rules');self.assertIn('ai_error',r);self.assertEqual(r['totals']['main'],100)
 def test_provider_request_and_response(self):
  answer={'candidates':[{'content':{'parts':[{'text':json.dumps({'headline':'Review pending workflow','observations':[{'metric_key':'bo_pending','note':'Decisions remain pending.','action':'Review field evidence.'}]})}]}}]}
  class Response:
   def __enter__(self):return io.StringIO(json.dumps(answer))
   def __exit__(self,*args):pass
  with patch.dict(os.environ,{'GEMINI_API_KEY':'test-secret','GEMINI_MODEL':'test-model'}),patch('urllib.request.urlopen',return_value=Response()) as call:r=agent.run(self.text,use_ai=True)
  request=call.call_args.args[0];self.assertIn('generateContent',request.full_url);self.assertNotIn('test-secret',request.full_url);self.assertNotIn('DEMO-0001',request.data.decode());self.assertEqual(r['mode'],'gemini');self.assertTrue(r['ai_review_required'])
 def test_provider_error_fallback(self):
  with patch.dict(os.environ,{'GEMINI_API_KEY':'test','GEMINI_MODEL':'test-model'}),patch('urllib.request.urlopen',side_effect=urllib.error.HTTPError('url',429,'Quota',{},None)):r=agent.run(self.text,use_ai=True)
  self.assertIn('429',r['ai_error']);self.assertEqual(r['mode'],'rules')
 def test_file_outputs_and_csv_safety(self):
  with tempfile.TemporaryDirectory() as d:
   r=agent.analyze(self.rows);r['blocks'][0]['scope']['Block']='=unsafe'
   p=agent.save(r,self.text,pathlib.Path(d));self.assertTrue((p/'summary.md').exists());self.assertIn("'=unsafe",(p/'block_priorities.csv').read_text(encoding='utf-8-sig'));self.assertNotEqual(p,agent.save(r,self.text,pathlib.Path(d)))
if __name__=='__main__':unittest.main()
