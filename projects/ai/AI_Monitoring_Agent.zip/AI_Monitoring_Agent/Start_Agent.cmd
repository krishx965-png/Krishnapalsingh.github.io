@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  start "Monitoring browser" http://127.0.0.1:8765
  py -3 server.py
) else (
  start "Monitoring browser" http://127.0.0.1:8765
  python server.py
)
pause
