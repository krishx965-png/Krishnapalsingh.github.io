# AI Monitoring Summary Agent

A local monitoring workflow for Krishnapal Singh Chauhan. Public sample records are fictional; no real enrolment exports, IDs or school names are packaged.

## Start on Windows

1. Extract the ZIP. Install Python 3.10+ if Python is not already available.
2. Double-click Start_Agent.cmd. If the browser opens before the server, reload after the terminal says ready.
3. Open http://127.0.0.1:8765. The synthetic sample loads automatically.
4. Choose English/Hindi, upload a monitoring CSV, and run analysis. Copy or download the summary.

Alternative: run `python server.py` inside the project folder. Keep the terminal open. Stop with Ctrl+C. No Python packages need installing. This server binds to your own computer only; it is not a public hosted AI backend.

## What works without an API key

CSV validation → exact calculations → district/block rankings → rules-based draft summary → JSON/Markdown/CSV exports. This is deterministic automation, not an LLM-generated narrative.

Required CSV columns:
CaseID, District, Block, InMain, InFuzzy, InQueue, OriginalScore, NewScore, MainQualityStatus, MainStatus, CVCompleted, BOStatus.

Source flags and CVCompleted are 0/1. Missing scores stay blank. Scores must be 0–100. MainQualityStatus is Yes, No or Not recorded; blank counts as not recorded. Blank required identifiers, duplicate CaseIDs, missing columns, malformed flags and invalid scores stop the report. Extra columns are ignored and excluded from AI inputs.

For the existing prepared Power BI CSVs, run:

```text
python agent.py --fact PATH/FactCases.csv --locations PATH/DimLocation.csv --language hi
```

Or use a flattened CSV:

```text
python agent.py --csv PATH/monitoring.csv --language en
```

Reports are saved into separate timestamped folders under reports/; existing reports are preserved. Data does not include targets, retention events or historical snapshots, so this version does not invent target achievement, retention or trends. CVCompleted is taken from the prepared source field; counts retain their main/queue populations.

## Optional real AI narrative (Gemini)

Configure GEMINI_API_KEY and GEMINI_MODEL on your computer, choosing a model available to your Google account. No secret belongs in GitHub or this package. In the same PowerShell window, set the key without putting its literal value in shell history:

```powershell
$agentKey = Read-Host 'Gemini API key' -AsSecureString
$agentPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($agentKey)
try { $env:GEMINI_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($agentPtr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($agentPtr) }
$env:GEMINI_MODEL = Read-Host 'Supported Gemini model ID'
python server.py
```

Gemini is optional. Its access, quota and pricing depend on your provider account. The app sends anonymous district/block aggregates, counts and fixed rules; no case identifiers or actual district/block names are sent. Raw rows stay local. Responses must be structured JSON, reference allowed metrics, and contain no digits in their narrative; the app attaches exact computed values separately. Qualitative recommendations still require human review. API failure, missing setup or rejected output produces an explicitly labelled rules-based fallback.

CLI AI mode: `python agent.py --csv PATH/monitoring.csv --ai --language hi` (same environment settings required).

Live Gemini execution has not been tested because no key/model connection was supplied. Provider integration and failure paths were tested with mocked responses. Local calculations, upload endpoint, sample reports and UI logic were tested.

Official API reference: https://ai.google.dev/api
Structured generation: https://ai.google.dev/api/generate-content

## Watch automation

```text
python agent.py --csv PATH/monitoring.csv --watch --language hi
```

The watcher checks the input every ten seconds and saves a report when the file contents change. Failed inputs are rejected and retried; no successful fingerprint is recorded for invalid inputs. Keep the process running; Ctrl+C stops it. Add `--ai` only if automatic sending of anonymous aggregate metrics to Gemini is intended. This package does not register system schedules, send WhatsApp messages or send email.

## Portfolio

The web portfolio demo runs rules-based analysis over saved synthetic snapshots. It is not a live AI endpoint. Its AI-prompt download can be used manually in an AI assistant. The downloadable local project provides optional real Gemini processing.

## Metric definitions

- Low original fuzzy: original score <70, restricted to fuzzy source membership.
- Queue coverage: low original fuzzy AND queue / low original fuzzy. Unknown denominator is N/A.
- BO Pending, Approved and Unmatch are separate; none implies CV completion.
- Quality flags and incomplete SR use the main enrolment population.
- Incomplete SR RAG: Red >20%; Amber 10–20%; Green <10%; no main population = N/A.
- Block priority uses summed follow-up flags. Flags can overlap and are not distinct case counts. Ties share a dense rank.
- Source exports overlap; they must not be added as main enrolments.
