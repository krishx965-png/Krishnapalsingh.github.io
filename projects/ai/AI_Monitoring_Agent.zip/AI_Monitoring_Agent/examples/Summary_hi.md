# निगरानी स्थिति — मसौदा

Mode: rules | Data: synthetic

| जिला | मुख्य enrolment | Quality Yes | Incomplete SR | Low fuzzy outside queue | BO pending |
|---|---:|---:|---:|---:|---:|
| District A | 52 | 36 | 8 | 6 | 3 |
| District B | 48 | 34 | 7 | 4 | 6 |

कुल मुख्य enrolment: 100. Queue coverage: 50.0%.

- Low fuzzy queue के बाहर: 10. Field verification के लिए cases जाँचें।
- BO decision pending: 9. Field evidence देखकर निर्णय लें।
- BO Unmatch: 1. Mismatch को reconcile करें।
- अधूरे school registers: 15. Register entry जाँचकर workflow पूरा करें।
- Quality flag दर्ज नहीं: 30. Missing flags जाँचें; इन्हें confirmed failure न मानें।

## Block follow-up प्राथमिकता

| Rank | District | Block | Follow-up flags (may overlap) |
|---:|---|---|---:|
| 1 | District A | Demo Block 1 | 10 |
| 1 | District B | Demo Block 3 | 10 |
| 2 | District B | Demo Block 4 | 8 |
| 3 | District A | Demo Block 2 | 7 |

## सीमाएँ
- No targets or historic snapshots supplied: target achievement and trends are unavailable.
- Queue presence is not completed verification.
- Original/new score counts are separate indicators, not a before/after trend.
- Block follow-up flags can overlap; they are not distinct case counts.
