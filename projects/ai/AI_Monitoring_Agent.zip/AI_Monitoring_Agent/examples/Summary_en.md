# Monitoring status — draft

Mode: rules | Data: synthetic

| District | Main enrolments | Quality Yes | Incomplete SR | Low fuzzy outside queue | BO pending |
|---|---:|---:|---:|---:|---:|
| District A | 52 | 36 | 8 | 6 | 3 |
| District B | 48 | 34 | 7 | 4 | 6 |

Total main enrolments: 100. Low-original-score queue coverage: 50.0%.

- Low original fuzzy cases outside the queue: 10. Check low-score cases and route eligible cases for field verification.
- BO decisions pending: 9. Review pending cases using field evidence; do not infer approval from queue presence.
- BO Unmatch cases: 1. Reconcile the mismatch before final enrolment reporting.
- Incomplete school registers: 15. Confirm the school-register entry and complete the register workflow.
- Quality flags not recorded: 30. Check missing flags; do not label them confirmed failures.

## Block follow-up priorities

| Rank | District | Block | Follow-up flags (may overlap) |
|---:|---|---|---:|
| 1 | District A | Demo Block 1 | 10 |
| 1 | District B | Demo Block 3 | 10 |
| 2 | District B | Demo Block 4 | 8 |
| 3 | District A | Demo Block 2 | 7 |

## Limits
- No targets or historic snapshots supplied: target achievement and trends are unavailable.
- Queue presence is not completed verification.
- Original/new score counts are separate indicators, not a before/after trend.
- Block follow-up flags can overlap; they are not distinct case counts.
